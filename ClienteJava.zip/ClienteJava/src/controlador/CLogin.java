/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import modelo.TestWS;
import vista.Cuentau;
import vista.Login;
import vista.Registro;

/**
 *
 * @author Pc
 */
public class CLogin implements ActionListener{
    Login vista = new Login();
    Registro vistaR = new Registro();
    Cuentau vistac = new Cuentau();
    TestWS model = new TestWS();
    
    public CLogin(Login vista) {
        this.vista = vista;
      
        this.vista.Registrarse.addActionListener(this);
        this.vista.Ingresar.addActionListener(this);
        vista.Res.setVisible(false);

    }

    public void inciar() {
        vista.setLocationRelativeTo(null);
       
        
    }

    @Override
    public void actionPerformed(ActionEvent e) {
         if (e.getSource() == vista.Ingresar) {
             System.out.println("Si entra");
             if(verificardatos()==true){
                 
                 vistac.setVisible(true);
             }else{
                 vista.Res.setVisible(true);
                 vista.Res.setText("El Usuario no se encontro");
             }
        }
         
         if (e.getSource() == vista.Registrarse) {
         CRegistro cl = new CRegistro (vistaR);
         vistaR.setVisible(true);
         
         }
         
    }
        
    public void guardardatos(){
        String u = vistaR.Usuario1.getText();
        String c1 = vistaR.clave1.getText();
        String c2 = vistaR.clave2.getText();
        Double s = Double.parseDouble(vistaR.saldo.getText());
        model.RegistrarU(u, c2, s);
    }
    
    public boolean verificardatos(){
        String u = vista.Usuario1.getText();
        String c1 = vista.clave1.getText();
     
        boolean res = model.verificardatos(u, c1);
        return res;
    }
  


}

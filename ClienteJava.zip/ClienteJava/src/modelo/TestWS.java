/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import ws.WSOperaciones;
import ws.WSOperaciones_Service;

/**
 *
 * @author Pc
 */
public class TestWS {
    WSOperaciones_Service ser = new WSOperaciones_Service() ;
        WSOperaciones cliente = ser.getWSOperacionesPort();
        
//    public static void main(String[] args) {
//        
//        
//         if(cliente.login("EdissonQuinde", "lacow")){
//            System.out.println("Datos Correctos");
//        }else{
//            System.out.println("Datos Incorrectos");
//        }
//         
//         //segundo metodo
//         System.out.println(cliente.procesarPago(4000, 1000));
//    }
    
    public Boolean validarclave (String clave1, String clave2){
        if(clave1.equals(clave2)){
             System.out.println("siu v");
        return true;
           
        }else{
             System.out.println("now v");
           return false;
        }
    }
    
    
    public void RegistrarU(String u, String c, Double s){
        System.out.println("res: "+ cliente.registro(u, c, s));
    }
    
    
    public boolean verificardatos(String u, String c){
        System.out.println("rev"+ cliente.verificardatos(u,c));
        boolean res =cliente.verificardatos(u,c);
        return res;
    }
}

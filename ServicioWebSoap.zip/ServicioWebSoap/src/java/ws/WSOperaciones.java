/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/WebServices/WebService.java to edit this template
 */
package ws;

import java.util.ArrayList;
import java.util.List;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import modelo.cliente;

/**
 *
 * @author Pc
 */
@WebService(serviceName = "WSOperaciones")
public class WSOperaciones {
cliente cliente1 = new cliente();
List<cliente> clientes= new ArrayList<cliente>();
    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "hello")
    public String hello(@WebParam(name = "name") String txt) {
        return "Hello " + txt + " !";
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "Login")
    public Boolean Login(@WebParam(name = "usuario") String usuario, @WebParam(name = "contrase\u00f1a") String contraseña) {
        //TODO write your implementation code here:
        if (usuario.equals("EdissonQuinde") && contraseña.equals("lacow")){
            return true;
        } else{
            return false;
        }
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "ProcesarPago")
    public int ProcesarPago(@WebParam(name = "total") int total, @WebParam(name = "pago") int pago) {
        //TODO write your implementation code here:
        if(pago>=total){
            return pago-total;
        }else{
            return -1;
        }
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "Registro")
    public Boolean Registro(@WebParam(name = "Usuario") String Usuario, @WebParam(name = "Clave") String Clave, @WebParam(name = "Saldo") double Saldo) {
        //TODO write your implementation code here:
        cliente1.setUsuario(Usuario);
        cliente1.setClave(Clave);
        cliente1.setSaldo(Saldo);
         clientes.add(cliente1);
        return true;
       
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "verificardatos")
    public Boolean verificardatos(@WebParam(name = "Usuario") String Usuario, @WebParam(name = "Contrase\u00f1a") String Contraseña) {
        //TODO write your implementation code here:
        int pos=-1;
        for (int i = 0; i < clientes.size(); i++) {
            if(clientes.get(i).getUsuario()==Usuario){
                if(clientes.get(i).getClave()==Contraseña) {
                    pos=i;
                }
            }else{
                pos=-1;
            }
        }
        if(pos!=-1){
            return true;
        }else{
            return false;
        }
    }

 
}

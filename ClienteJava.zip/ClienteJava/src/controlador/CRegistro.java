/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import modelo.TestWS;
import vista.Login;
import vista.Registro;

/**
 *
 * @author Pc
 */
public class CRegistro implements ActionListener{
    Registro vistaR = new Registro();
    Login vistaL = new Login();
   
    
    TestWS model = new TestWS();
    
    public CRegistro(Registro vista) {
        this.vistaR = vista;
      
        this.vistaR.Registrar.addActionListener(this);
        vista.Res.setVisible(false);

    }

    public void inciar() {
        vistaR.setLocationRelativeTo(null);
       
        
    }

    @Override
    public void actionPerformed(ActionEvent e) {
         if (e.getSource() == vistaR.Registrar) {
             System.out.println("Si entra");
              String c1 = vistaR.clave1.getText();
              String c2 = vistaR.clave2.getText();
            if ( model.validarclave(c1, c2)==true){
                guardardatos();
                System.out.println("siuu");
                vistaR.Res.setVisible(true);
                vistaR.Res.setText("Usuario Registrado exitosamente");
                 CLogin cl = new CLogin(vistaL);
                vistaL.setVisible(true);
                vistaR.setVisible(false);
            }
            else{
                vistaR.Res.setVisible(true);
                vistaR.Res.setText("Las claves no coinciden");
            }
        }
    }
        
    public void guardardatos(){
        String u = vistaR.Usuario1.getText();
        String c1 = vistaR.clave1.getText();
        String c2 = vistaR.clave2.getText();
        Double s = Double.parseDouble(vistaR.saldo.getText());
        model.RegistrarU(u, c2, s);
    }
  


}
